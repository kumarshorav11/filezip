package com.hcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.engine.service.impl.RuleEngineService;

import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
public class RuleEngineController {
	
	@Autowired
	private RuleEngineService ruleEngineService;
	
	@GetMapping("/api/rule")
	public String ruleFired() {
		log.info("Success");
		return ruleEngineService.callRuleEngine();
	}

}
