package com.hcl.template;

import org.drools.core.spi.KnowledgeHelper;

import com.hcl.rules.config.RuleConfig;

import lombok.extern.log4j.Log4j2;
@Log4j2
public class RuleConfigurationCreator {
	
	public static void loadRuleConfig(KnowledgeHelper kh, String ruleId, String ruleName, String ruleDesc, int rowId) {
		RuleConfig ruleConfig = new RuleConfig(ruleId != null ? ruleId : "", 
				ruleName != null ? ruleName : "", ruleDesc != null ? ruleDesc : "", rowId);
	
		//log.debug("Rule config : "+ruleConfig);
		kh.insert(ruleConfig);
	}

}
