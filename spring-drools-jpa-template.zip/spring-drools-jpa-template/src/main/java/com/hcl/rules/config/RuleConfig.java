package com.hcl.rules.config;

public class RuleConfig {

	public RuleConfig(String ruleId, String ruleName, String ruleDesc, int ruleRowId) {
		super();
		this.ruleId = ruleId;
		this.ruleName = ruleName;
		this.ruleDesc = ruleDesc;
		this.ruleRowId = ruleRowId;
	}

	private String ruleId;
	private String ruleName;
	private String ruleDesc;
	private int ruleRowId;

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleDesc() {
		return ruleDesc;
	}

	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}

	public int getRuleRowId() {
		return ruleRowId;
	}

	public void setRuleRowId(int ruleRowId) {
		this.ruleRowId = ruleRowId;
	}

	@Override
	public String toString() {
		return "RuleConfig [ruleId=" + ruleId + ", ruleName=" + ruleName + ", ruleDesc=" + ruleDesc + ", ruleRowId="
				+ ruleRowId + "]";
	}

}
