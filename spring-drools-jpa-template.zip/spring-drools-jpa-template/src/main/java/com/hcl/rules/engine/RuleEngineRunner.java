package com.hcl.rules.engine;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import org.drools.decisiontable.ExternalSpreadsheetCompiler;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.KieRepository;
import org.kie.api.builder.Message.Level;
import org.kie.api.builder.ReleaseId;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class RuleEngineRunner {

	private KieServices kieServices;
	private KieFileSystem kieFileSystem;

	private static final String DRL_CONFIG_PATH = "src/main/resources/com/hcl/rules/config/";
	private static final String DRL_PATH = "src/main/resources/com/hcl/rules/";
	private static final String RESOURCE_PATH = "src/main/resources/";
	private static final String RULES_PATH = "rules";

	@Autowired
	public RuleEngineRunner(KieServices kieServices, KieContainer kieConatainer) {
		this.kieServices = kieServices;
		this.kieFileSystem = this.kieServices.newKieFileSystem();
	}

	public RuleEngineRunner() {

	}

	/**
	 * To Generate DRL's file from DRT using excel sheet.
	 * 
	 * @param sheetName
	 * @param drtName
	 * @param tabName
	 * @param startRow
	 * @param startCol
	 * @param drlfileName
	 * @return
	 */
	public String generateAndWriteToRuleFile(String sheetName, String drtName, String tabName, int startRow,
			int startCol, String drlfileName) {
		ExternalSpreadsheetCompiler excelSheetCompiler = new ExternalSpreadsheetCompiler();
		InputStream excelSheetDataStream = RuleEngineRunner.class.getClassLoader().getResourceAsStream(sheetName);
		InputStream drtDataStream = RuleEngineRunner.class.getClassLoader().getResourceAsStream(drtName);
		String drlRuleConfig = excelSheetCompiler.compile(excelSheetDataStream, tabName, drtDataStream, startRow,
				startCol);
		log.debug("Drl Gnenerated : " + drlRuleConfig);
		if (!"".equals(drlRuleConfig)) {
			writeDrlIntoFile(drlRuleConfig, DRL_CONFIG_PATH + drlfileName);
		}

		return drlRuleConfig;
	}

	public String generateRuleFile(String sheetName, String drtName, String tabName, int startRow, int startCol,
			String drlfileName) {
		ExternalSpreadsheetCompiler excelSheetCompiler = new ExternalSpreadsheetCompiler();
		InputStream excelSheetDataStream = RuleEngineRunner.class.getClassLoader().getResourceAsStream(sheetName);
		InputStream drtDataStream = RuleEngineRunner.class.getClassLoader().getResourceAsStream(drtName);
		String drlRuleConfig = excelSheetCompiler.compile(excelSheetDataStream, tabName, drtDataStream, startRow,
				startCol);
		log.debug("Drl Gnenerated : " + drlRuleConfig);
		return drlRuleConfig;
	}

	/**
	 * Write in to drools file
	 * 
	 * @param drlString
	 * @param destinationPath
	 */
	public void writeDrlIntoFile(String drlString, String destinationPath) {
		try {
			File file = new File(destinationPath);
			BufferedWriter output = new BufferedWriter(new FileWriter(file));
			output.write(drlString);
			output.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void addRuleFileToKieFileSystem(String rulefile) {
		Resource resource = kieServices.getResources().newClassPathResource(rulefile);
		String resourcepath = RESOURCE_PATH + rulefile;
		kieFileSystem.write(resourcepath, resource);
	}

	public KieContainer buildKnowledgeContainer() {
		KieRepository kieRepository = kieServices.getRepository();
		kieRepository.addKieModule(new KieModule() {
			@Override
			public ReleaseId getReleaseId() {
				return kieRepository.getDefaultReleaseId();
			}
		});

		KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem).buildAll();
		if (kieBuilder.getResults().hasMessages(Level.ERROR)) {
			throw new RuntimeException("Build Errors:\n" + kieBuilder.getResults().toString());
		}
		

		return kieServices.newKieContainer(kieBuilder.getKieModule().getReleaseId());

	}

	
	/*public static void main(String... strings) {

		RuleEngineRunner ruleEngine = new RuleEngineRunner(KieServices.Factory.get(),KieServices.Factory.get().getKieClasspathContainer());
		ruleEngine.generateAndWriteToRuleFile("business-rules-structure.xls", "./com/hcl/templates/rulesconfig.drt","RULE_DESCRIPTION", 3, 2, "rulesconfig.drl");
		List<String> ruleFiles = new ArrayList<String>();
		ruleFiles.add("com/hcl/rules/config/rulesconfig.drl");
		ruleFiles.add("com/hcl/rules/matching-rules.drl");
		for (String ruleFile : ruleFiles) {
			ruleEngine.addRuleFileToKieFileSystem(ruleFile);
		}
		
		KieBase kieBase = ruleEngine.buildKnowledgeContainer().getKieBase();
		KieSession session = kieBase.newKieSession();
		session.setGlobal("$logger", RuleEngineRunner.log);
		
		//Insert Facts to RE
		RuleConfigModel ruleConfigModel = new RuleConfigModel();
		ruleConfigModel.setCount(0);
		session.insert(ruleConfigModel);		
		session.fireAllRules();
		log.info("Total Facts : "+ruleConfigModel.getRuleConfigs().size());

	}*/
}
