package com.hcl;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import lombok.extern.log4j.Log4j2;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@Log4j2
public class SpringDroolsRuleTemplateApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(SpringDroolsRuleTemplateApplication.class, args);
	}
	
	@Bean
	public KieServices kieServices() {
		log.info("Kie Services Bean Initialised");
		return KieServices.Factory.get();
	}
	
	@Bean
	public KieContainer kieConatiner() {
		log.info("Kie Container Bean Initialised");
		return KieServices.Factory.get().getKieClasspathContainer();
	}
	
	
	
	
}
