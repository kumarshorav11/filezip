package com.hcl.engine.utilities;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.drools.core.common.DroolsObjectInputStream;
import org.drools.core.common.DroolsObjectOutputStream;
import org.kie.api.KieBase;


public class DroolsStreamUtils {

    /**
     * This routine would stream out the give object uncompressed and store the streamed contents in
     * the return byte array.  The output contents could only be read by the corresponding "streamIn"
     * method of this class.
     * @param object
     * @return
     * @throws IOException
     */
    public static  byte[] streamOut(Object object) throws IOException {
        return streamOut(object, false);
    }

    /**
     * This routine would stream out the give object, uncompressed or compressed depending on the given flag,
     * and store the streamed contents in the return byte array. The output contents could only be read by
     * the corresponding "streamIn" method of this class.
     * @param object
     * @param compressed
     * @return
     * @throws IOException
     */
    public static  byte[] streamOut(Object object, boolean compressed) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();

        streamOut(bytes, object, compressed);
        bytes.flush();
        bytes.close();
        return bytes.toByteArray();
    }

    /**
     * This method would stream out the given object to the given output stream uncompressed.
     * The output contents could only be read by the corresponding "streamIn" method of this class.
     * @param out
     * @param object
     * @throws IOException
     */
    public static  void streamOut(OutputStream out, Object object) throws IOException {
        streamOut(out, object, false);
    }

    /**
     * This method would stream out the given object to the given output stream uncompressed or compressed
     * depending on the given flag.  The output contents could only be read by the corresponding "streamIn"
     * methods of this class.
     * @param out
     * @param object
     * @throws IOException
     */
    public static  void streamOut(OutputStream out, Object object, boolean compressed) throws IOException {
        if (compressed) {
            out = new GZIPOutputStream(out);
        }
        DroolsObjectOutputStream doos = null;
        try {
            doos = new DroolsObjectOutputStream(out);
            doos.writeObject(object);
        } finally {
            if( doos != null ) {
                doos.close();
            }
            if (compressed) {
                out.close();
            }
        }
    }

    /**
     * This method reads the contents from the given byte array and returns the object.  It is expected that
     * the contents in the given buffer was not compressed, and the content stream was written by the corresponding
     * streamOut methods of this class.
     * @param bytes
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(byte[] bytes) throws IOException, ClassNotFoundException {
        return streamIn(bytes, null);
    }

    /**
     * This method reads the contents from the given byte array and returns the object.  It is expected that
     * the contents in the given buffer was not compressed, and the content stream was written by the corresponding
     * streamOut methods of this class.
     * @param bytes
     * @param classLoader
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(byte[] bytes, ClassLoader classLoader)
            throws IOException, ClassNotFoundException {
        return streamIn(bytes, classLoader, false);
    }

    /**
     * This method reads the contents from the given byte array and returns the object.  The contents in the given
     * buffer could be compressed or uncompressed depending on the given flag.  It is assumed that the content
     * stream was written by the corresponding streamOut methods of this class.
     * @param bytes
     * @param compressed
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(byte[] bytes, boolean compressed) throws IOException, ClassNotFoundException {
        return streamIn(new ByteArrayInputStream(bytes), null, compressed);
    }

    /**
     * This method reads the contents from the given byte array and returns the object.  The contents in the given
     * buffer could be compressed or uncompressed depending on the given flag.  It is assumed that the content
     * stream was written by the corresponding streamOut methods of this class.
     * @param bytes
     * @param classLoader
     * @param compressed
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(byte[] bytes, ClassLoader classLoader, boolean compressed)
            throws IOException, ClassNotFoundException {
        return streamIn(new ByteArrayInputStream(bytes), classLoader, compressed);
    }

    /**
     * This method reads the contents from the given input stream and returns the object.  It is expected that
     * the contents in the given stream was not compressed, and it was written by the corresponding
     * streamOut methods of this class.
     * @param in
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(InputStream in) throws IOException, ClassNotFoundException {
        return streamIn(in, null, false);
    }

    /**
     * This method reads the contents from the given input stream and returns the object.  It is expected that
     * the contents in the given stream was not compressed, and it was written by the corresponding
     * streamOut methods of this class.
     * @param in
     * @param classLoader
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(InputStream in, ClassLoader classLoader)
            throws IOException, ClassNotFoundException {
        return streamIn(in, classLoader, false);
    }

    /**
     * This method reads the contents from the given input stream and returns the object.  The contents in the given
     * stream could be compressed or uncompressed depending on the given flag.  It is assumed that the content
     * stream was written by the corresponding streamOut methods of this class.
     * @param in
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static  Object streamIn(InputStream in, ClassLoader classLoader, boolean compressed)
            throws IOException, ClassNotFoundException {
        if (compressed)
            in  = new GZIPInputStream(in);
        return new DroolsObjectInputStream(in, classLoader).readObject();
     }
    
    public static byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ObjectOutputStream os = new ObjectOutputStream(out);
        os.writeObject(obj);
        return out.toByteArray();
    }
    
    public static Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        ObjectInputStream is = new ObjectInputStream(in);
        return is.readObject();
    }
    
    /**
	 * Converts a Serializable Java object to compressed binary data suitable
	 * for caching or saving in a database as a BLOB.
	 * 
	 * @param serializable
	 *            the object to serialize.
	 * @return compressed binary data for serializable object.
	 * @throws IOException
	 *             on IO error.
	 */
	public static byte[] convertSerializableToBytes(final Serializable serializable) throws IOException {
		final ByteArrayOutputStream bos = new ByteArrayOutputStream();
		final GZIPOutputStream gzipOutStream = new GZIPOutputStream(bos);
		final ObjectOutputStream out = new ObjectOutputStream(gzipOutStream);
		out.writeObject(serializable);
		out.close();
		return bos.toByteArray();
	}

	/**
	 * Creates a KieBase from compressed binary data.
	 * 
	 * @param kiebaseBytes
	 *            the binary compressed data to be used for input.
	 * @return the KieBase object constructed from the input data.
	 * @throws ClassNotFoundException
	 *             if the compressed binary data includes unknown serialized
	 *             Java Class instances.
	 * @throws IOException
	 *             on IO error.
	 */
	public static KieBase convertKieBasefromBytes(final byte[] kiebaseBytes)
			throws ClassNotFoundException, IOException {
		final ByteArrayInputStream bis = new ByteArrayInputStream(kiebaseBytes);
		final GZIPInputStream gzipInStream = new GZIPInputStream(bis);
		final ObjectInputStream in = new ObjectInputStream(gzipInStream);
		KieBase kieBase = (KieBase) in.readObject();
		in.close();
		return kieBase;
	}
	/**
	 * Converts a KieBase to compressed binary data suitable for caching or
	 * saving in a database as a BLOB.
	 * 
	 * @param kieBase
	 *            the KieBase to convert.
	 * @return compressed binary data for KieBase.
	 * @throws IOException
	 *             on IO error.
	 */
	public static byte[] convertKieBaseToBytes(final KieBase kieBase)
			throws IOException {
		final ByteArrayOutputStream bos = new ByteArrayOutputStream();
		final GZIPOutputStream gzipOutStream = new GZIPOutputStream(bos);
		final ObjectOutputStream out = new ObjectOutputStream(gzipOutStream);
		out.writeObject(kieBase);
		out.close();
		return bos.toByteArray();
	}
	
	public static byte[] serializeKieBase(KieBase kieBase) throws IOException {
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    ObjectOutputStream oos = new DroolsObjectOutputStream(baos);
	    oos.writeObject(kieBase);
	    oos.close();

	    return baos.toByteArray();
	}

	public static KieBase deserializeKieBase(byte[] serializedBase) throws IOException, ClassNotFoundException {
	    ByteArrayInputStream is = new ByteArrayInputStream(serializedBase);
	    ObjectInputStream ois = new DroolsObjectInputStream(is);

	    return (KieBase) ois.readObject();
	}
}