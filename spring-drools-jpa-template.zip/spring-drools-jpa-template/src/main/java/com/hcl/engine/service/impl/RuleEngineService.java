package com.hcl.engine.service.impl;

import java.io.IOException;

import org.kie.api.KieBase;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.engine.entity.RuleEngineConfig;
import com.hcl.engine.jpa.repository.IEngineRepository;
import com.hcl.engine.model.RuleConfigModel;
import com.hcl.engine.service.IRuleEngineService;
import com.hcl.engine.utilities.DroolsStreamUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class RuleEngineService implements IRuleEngineService {

	private KieContainer KieContainer;
	private final String KIE_SESSION_NAME = "ksession-rules";
	private IEngineRepository engineRepository;

	@Autowired
	public RuleEngineService(KieContainer kieContainer, IEngineRepository engineRepository) {
		this.KieContainer = kieContainer;
		this.engineRepository = engineRepository;
		buildKieSession();

	}

	@Override
	public String callRuleEngine() {
		int totalFacts = 0;
		KieSession kieSession = null;

		log.info("Entering in to Rule Engine Zone .....");
		try {

			// Get KieBase Object from DB
			log.info("Getting KieBase object from KieBase.");
			RuleEngineConfig sessionObj = engineRepository.findAll().stream()
					.filter(p -> p.getSessionName().equalsIgnoreCase(KIE_SESSION_NAME)).findFirst().get();
			KieBase kieBase = DroolsStreamUtils.deserializeKieBase(sessionObj.getKieBase());
			log.info("Creating a new kie session from kie base.");
			kieSession = kieBase.newKieSession();
			kieSession.setGlobal("$logger", RuleEngineService.log);
			// Insert Facts to RE
			RuleConfigModel ruleConfigModel = new RuleConfigModel();
			ruleConfigModel.setCount(0);
			// Inserting fact in to rule engine
			kieSession.insert(ruleConfigModel);
			kieSession.fireAllRules();
			totalFacts = ruleConfigModel.getRuleConfigs().size();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			kieSession.dispose();
		}

		return totalFacts + "";

	}

	private void buildKieSession() {
		log.info(
				"Intialising KieBase from named ksession. Catching this kie base to create the kie session multiple times without heavy lifting of kiebase.");
		KieBase kieBase = KieContainer.newKieSession(KIE_SESSION_NAME).getKieBase();
		try {
			engineRepository.save(new RuleEngineConfig(KIE_SESSION_NAME, DroolsStreamUtils.serializeKieBase(kieBase)));

			log.info("Session saved in to DB.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
