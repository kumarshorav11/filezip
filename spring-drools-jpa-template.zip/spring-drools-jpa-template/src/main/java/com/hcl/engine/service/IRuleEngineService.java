package com.hcl.engine.service;

public interface IRuleEngineService {
	public String callRuleEngine();

}
