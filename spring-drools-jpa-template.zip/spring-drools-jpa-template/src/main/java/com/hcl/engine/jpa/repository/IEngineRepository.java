package com.hcl.engine.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.engine.entity.RuleEngineConfig;

public interface IEngineRepository extends JpaRepository<RuleEngineConfig, Long> {

}
