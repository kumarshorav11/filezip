package com.hcl.engine.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.kie.api.KieBase;

@Entity
@Table(name = "ENGINE_SESSION")
public class RuleEngineConfig implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RuleEngineConfig() {
		super();
	}
	public RuleEngineConfig(String sessionName) {
		super();
		this.sessionName = sessionName;
	}

	public RuleEngineConfig(String sessionName, byte[] kieBase) {
		super();
		this.sessionName = sessionName;
		this.kieBase = kieBase;

	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "SESSION_NAME")
	private String sessionName;

	@Lob
	@Column(name = "KIE_BASE")//, columnDefinition = "BLOB"
	private byte[] kieBase;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public  byte[] getKieBase() {
		return kieBase;
	}

	public void setKieBase( byte[] kieBase) {
		this.kieBase = kieBase;
	}

}
