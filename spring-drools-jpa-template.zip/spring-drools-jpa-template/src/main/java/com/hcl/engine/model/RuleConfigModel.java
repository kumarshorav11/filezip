package com.hcl.engine.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.hcl.rules.config.RuleConfig;

public class RuleConfigModel implements Serializable{
	private int count;
	private List<RuleConfig> ruleConfigs;
	
	public RuleConfigModel() {
		super();
		this.ruleConfigs= new ArrayList<RuleConfig>();
		
	}
	
	public RuleConfigModel(int count) {
		super();
		this.ruleConfigs= new ArrayList<RuleConfig>();
		this.count = count;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}


	public List<RuleConfig> getRuleConfigs() {
		return ruleConfigs;
	}


	public void setRuleConfigs(List<RuleConfig> ruleConfigs) {
		this.ruleConfigs = ruleConfigs;
	}


	@Override
	public String toString() {
		return "RuleConfigModel [count=" + count + ", ruleConfigs=" + ruleConfigs + "]";
	}
	
	
	

}
